const redux = require("redux");
const reduxLogger = require("redux-logger")

// Destructuring
const { applyMiddleware } = redux;
const { createLogger } = reduxLogger;


// Actions
const ORDER_CAKE = "ORDER_CAKE";
const RESTOCK_CAKE = "RESTOCK_CAKE";

// Action Creators
function orderCake(qty = 1) {
    return {
        type: ORDER_CAKE,
        payload: qty
    }
}

function restockCake(qty = 1) {
    return {
        type: RESTOCK_CAKE,
        payload: qty
    }
}


// Cakes Initial State 
const cakeInitialState = {
    numOfCakes: 10
}


// Cake Reducer
const cakeReducer = (state = cakeInitialState, action) => {
    switch (action.type) {
        case ORDER_CAKE:
            return {
                ...state,
                numOfCakes: state.numOfCakes - action.payload
            }

        case RESTOCK_CAKE:
            return {
                ...state,
                numOfCakes: state.numOfCakes + action.payload
            }

        default:
            return state
    }
}

// Creating Logger Middleware
const loggerMiddleware = createLogger();

// Create Store & Passing Middleware
const store = redux.createStore(cakeReducer, applyMiddleware(loggerMiddleware));

store.dispatch(orderCake(3));
store.dispatch(orderCake(2));
store.dispatch(restockCake(5));
