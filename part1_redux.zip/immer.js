const redux = require("redux");
const { produce } = require("immer");

const initialState = {
    name: "Param",
    address: {
        city: "Phagwara",
        state: "Punjab"
    }
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "UPDATE":
            //OLD WAY
            // return {
            //     ...state,
            //     address: {
            //         ...state.address,
            //         state: "Karnataka"
            //     }
            // }

            // WITH IMMER
            return produce(state, (draft) => {
                draft.address.state = "Karnataka"
            })
        default:
            return state;
    }
}

const store = redux.createStore(reducer);
store.subscribe(() => {
    console.log(store.getState());
})

store.dispatch({ type: "UPDATE" });