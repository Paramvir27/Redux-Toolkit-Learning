const redux = require("redux");

// Actions
const ORDER_CAKE = "ORDER_CAKE";
const RESTOCK_CAKE = "RESTOCK_CAKE";
const ORDER_ICECREAM = "ORDER_ICECREAM";
const RESTOCK_ICECREAM = "RESTOCK_ICECREAM";


// Action Creators
function orderCake(qty = 1) {
    return {
        type: ORDER_CAKE,
        payload: qty
    }
}

function restockCake(qty = 1) {
    return {
        type: RESTOCK_CAKE,
        payload: qty
    }
}

function orderIcecream(qty = 1) {
    return {
        type: ORDER_ICECREAM,
        payload: qty
    }
}

function restockIcecream(qty = 1) {
    return {
        type: RESTOCK_ICECREAM,
        payload: qty
    }
}


// Cakes Initial State 
const cakeInitialState = {
    numOfCakes: 10
}

// Icecream Initial State 
const icecreamInitialState = {
    numOfIcecreams: 20
}



// Cake Reducer
const cakeReducer = (state = cakeInitialState, action) => {
    switch (action.type) {
        case ORDER_CAKE:
            return {
                ...state,
                numOfCakes: state.numOfCakes - action.payload
            }

        case RESTOCK_CAKE:
            return {
                ...state,
                numOfCakes: state.numOfCakes + action.payload
            }

        default:
            return state
    }
}

// Icecream Reducer
const icecreamReducer = (state = icecreamInitialState, action) => {
    switch (action.type) {
        case ORDER_ICECREAM:
            return {
                ...state,
                numOfIcecreams: state.numOfIcecreams - action.payload
            }

        case RESTOCK_ICECREAM:
            return {
                ...state,
                numOfIcecreams: state.numOfIcecreams + action.payload
            }

        default:
            return state
    }
}


// Root Reducer 
const rootReducer = redux.combineReducers({
    cakes: cakeReducer,
    icecreams: icecreamReducer
})


// Creating Store 
const store = redux.createStore(rootReducer);


const actions = redux.bindActionCreators(
    {
        orderCake,
        restockCake,
        orderIcecream,
        restockIcecream
    },
    store.dispatch
)

console.log("INITIAL STATE:", store.getState())

const unsubsribe = store.subscribe(() => {
    console.log("UPDATED STATE:", store.getState())
})


// store.dispatch(orderCake(5));


actions.orderCake();
actions.orderCake();
actions.restockCake(10);
actions.orderIcecream(2);
actions.orderIcecream(2);
actions.restockIcecream(10)



// store.dispatch(actionCakeOrder());
// store.dispatch(actionCakeOrder());
// store.dispatch(actionAddNewCake(10));



unsubsribe();
