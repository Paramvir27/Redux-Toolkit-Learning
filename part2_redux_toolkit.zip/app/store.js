const reduxToolkit = require("@reduxjs/toolkit");
const cakeReducer = require("../features/cakes/cakeSlice");
const icecreamReducer = require("../features/icecream/icecreamSlice");
const userReducer = require("../features/users/userSlice");
const reduxLogger = require("redux-logger");

const { configureStore } = reduxToolkit;
const { createLogger } = reduxLogger;

const logger = createLogger();

const store = configureStore({
    reducer: {
        cake: cakeReducer,
        icecream: icecreamReducer,
        user: userReducer
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger)
})

module.exports = store;