const store = require("./app/store");
const { cakeActions } = require("./features/cakes/cakeSlice");
const { icecreamActions } = require("./features/icecream/icecreamSlice");
const { fetchUsers } = require("./features/users/userSlice");

store.dispatch(fetchUsers());

// store.dispatch(cakeActions.ordered(2));
// store.dispatch(cakeActions.ordered(3));
// store.dispatch(cakeActions.restock(10));
// store.dispatch(icecreamActions.restock(10));