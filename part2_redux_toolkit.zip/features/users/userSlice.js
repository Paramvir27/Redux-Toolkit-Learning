const reduxToolkit = require("@reduxjs/toolkit");
const axios = require("axios");

const { createSlice, createAsyncThunk } = reduxToolkit;

const initialState = {
    loading: false,
    users: [],
    error: ""
}

const fetchUsers = createAsyncThunk("user/fetchusers", () => {
    // createAsyncThunk generates "pending", "fulfilled" & "rejected" as action types.

    // Promise can be in "pending" | "fulfilled" | "rejected" state
    return axios.get("https://jsonplaceholder.typicode.com/userss")
        .then((response) => response.data.map(user => user.id));
})

const userSlice = createSlice({
    name: "user",
    initialState,
    extraReducers: (builder) => {
        builder.addCase(fetchUsers.pending, (state, action) => {
            state.loading = true;
        })
        builder.addCase(fetchUsers.fulfilled, (state, action) => {
            state.loading = false;
            state.users = action.payload;
            state.error = ""
        })
        builder.addCase(fetchUsers.rejected, (state, action) => {
            state.loading = false;
            state.users = [];
            state.error = action.error.message
        })
    }
})

module.exports = userSlice.reducer;
module.exports.fetchUsers = fetchUsers;