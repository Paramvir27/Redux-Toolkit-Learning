const reduxToolkit = require("@reduxjs/toolkit");
const { createSlice } = reduxToolkit;

// Initial State
const initialState = {
    numOfIcecreams: 20
}

// Slice
const icecreamSlice = createSlice({
    name: "icecream",
    initialState,
    reducers: {
        // Actions
        "ordered": (state, action) => {
            state.numOfIcecreams -= action.payload
        },
        "restock": (state, action) => {
            state.numOfIcecreams += action.payload
        },
    },
    extraReducers: {
        ["cake/ordered"]: (state, action) => {
            state.numOfIcecreams -= action.payload
        },
    }
})

// Default Export
module.exports = icecreamSlice.reducer;

// Named Export
module.exports.icecreamActions = icecreamSlice.actions;