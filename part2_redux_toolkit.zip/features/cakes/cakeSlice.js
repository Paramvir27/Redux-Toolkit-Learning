const reduxToolkit = require("@reduxjs/toolkit");
const { createSlice } = reduxToolkit;

// Initial State
const initialState = {
    numOfCakes: 10
}

// Slice
const cakeSlice = createSlice({
    name: "cake",
    initialState,
    reducers: {
        // Actions
        "ordered": (state, action) => {
            state.numOfCakes -= action.payload
        },
        "restock": (state, action) => {
            state.numOfCakes += action.payload
        },
    }
})

// Default Export
module.exports = cakeSlice.reducer;

// Named Export
module.exports.cakeActions = cakeSlice.actions;