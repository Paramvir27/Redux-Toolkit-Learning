import { useSelector, useDispatch } from "react-redux";
import { ordered, restocked } from "./icecreamSlice";

const IcecreamView = (params) => {
    const dispatch = useDispatch();
    const numberOfIcecreams = useSelector((state) => state.icecream.numOfIcecreams)

    return <>
        <h1>Icecream View</h1>
        <h3>Number of Icecreams = {numberOfIcecreams}</h3>

        <button onClick={() => dispatch(ordered(1))}>Order</button>
        <button onClick={() => dispatch(restocked(1))}>Restock</button>
    </>
}

export default IcecreamView;