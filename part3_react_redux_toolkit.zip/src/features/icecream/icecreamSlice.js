import { createSlice } from "@reduxjs/toolkit";

// Initial State
const initialState = {
    numOfIcecreams: 20
}

// Slice
const icecreamSlice = createSlice({
    name: "icecream",
    initialState,
    reducers: {
        // Actions
        "ordered": (state, action) => {
            state.numOfIcecreams -= action.payload
        },
        "restocked": (state, action) => {
            state.numOfIcecreams += action.payload
        },
    },
    extraReducers: {
        ["cake/ordered"]: (state, action) => {
            state.numOfIcecreams -= action.payload
        },
    }
})

// Default Export
export default icecreamSlice.reducer;

// Named Export
export const { ordered, restocked } = icecreamSlice.actions;