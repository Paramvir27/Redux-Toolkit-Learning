import { useSelector, useDispatch } from "react-redux";
import { fetchUsers } from "./userSlice";

const UserView = (params) => {
    const { loading, users, error } = useSelector((state) => state.user)
    const dispatch = useDispatch();

    return <>
        <h1>Users List</h1>
        <button onClick={() => dispatch(fetchUsers())}>Fetch Users</button>

        {loading && <div> Loading...</div>}
        {error && <div> {error}</div>}
        {users.length ? users.map(id => <div>{id}</div>) : ""}
    </>
}

export default UserView;