import { createSlice } from "@reduxjs/toolkit";


// Initial State
const initialState = {
    numOfCakes: 10
}

// Slice
const cakeSlice = createSlice({
    name: "cake",
    initialState,
    reducers: {
        // Actions
        "ordered": (state, action) => {
            state.numOfCakes -= action.payload
        },
        "restocked": (state, action) => {
            state.numOfCakes += action.payload
        },
    }
})

// Default Export
export default cakeSlice.reducer;

// Named Export
export const { ordered, restocked } = cakeSlice.actions;
