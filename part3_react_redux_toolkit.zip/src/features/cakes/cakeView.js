import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { ordered, restocked } from "./cakeSlice";

const CakeView = (params) => {
    const dispatch = useDispatch()
    const [value, setValue] = React.useState(1)
    const numberOfCakes = useSelector((state) => state.cake.numOfCakes)

    return <>
        <h1>CakeView View</h1>
        <h3>Number of Cakes = {numberOfCakes}</h3>
        <input type="text" value={value} onChange={(e) => setValue(e.target.value)} /> 
        <button onClick={() => dispatch(ordered(value))}>Order</button>
        <button onClick={() => dispatch(restocked(1))}>Restock</button>
    </>
}

export default CakeView;

