import CakeView from "./features/cakes/cakeView";
import IcecreamView from "./features/icecream/icrecreamView";
import UserView from "./features/users/userView";

function App() {
  return (
    <div className="App">
      <CakeView />
      <IcecreamView />
      <UserView />
    </div>
  );
}

export default App;
